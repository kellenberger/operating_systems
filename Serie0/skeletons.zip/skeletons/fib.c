/* gcc -Wall -O2 fib.c */

#include <stdio.h>
#include <stdint.h>

int fib(int a) {
	/* TODO: implementation */
}

int main(void)
{
	/* TODO: implementation */

	return 0;
}
