/* gcc -Wall net.c */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

int main(int argc, char *argv[])
{
	uint8_t num0;
	uint8_t num1;
	uint8_t sum;

	/* TODO: Implementation */

	printf("%u * %u = %u\n", num0, num1, sum);

	return 0;
}
